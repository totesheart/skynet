<header class="header-area header-area-2 innar-page-menu m4">
    <div class="header-top pl-30 pr-30">
        <div class="myrow align-items-center">
            @include('front.partials.menu.topContent')
        </div>
    </div>
    <div class="header-nav">
        <div class="navigation">
            <nav class="navbar navbar-expand-lg navbar-light ">
                @include('front.partials.menu.nav-item')
            </nav>
        </div> <!-- navigation -->
    </div>
</header>