<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Experince extends Model
{
    //
}
