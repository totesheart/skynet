<?php $__env->startSection('content'); ?>

<?php if ($__env->exists('front.partials.section-partials.home')) echo $__env->make('front.partials.section-partials.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.about')) echo $__env->make('front.partials.section-partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.funfact')) echo $__env->make('front.partials.section-partials.funfact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.interests')) echo $__env->make('front.partials.section-partials.interests', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.service')) echo $__env->make('front.partials.section-partials.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.resume')) echo $__env->make('front.partials.section-partials.resume', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.portfolio')) echo $__env->make('front.partials.section-partials.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.pricingplan')) echo $__env->make('front.partials.section-partials.pricingplan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.testimonials')) echo $__env->make('front.partials.section-partials.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.faq')) echo $__env->make('front.partials.section-partials.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.blog')) echo $__env->make('front.partials.section-partials.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.client')) echo $__env->make('front.partials.section-partials.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\local\liveporichoy\core\resources\views/front/index.blade.php ENDPATH**/ ?>