<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daynamicpage extends Model
{
    protected $guarded = [];
}
