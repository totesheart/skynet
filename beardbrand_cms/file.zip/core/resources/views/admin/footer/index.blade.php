@extends('admin.layout')

@section('content')

<div class="content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">{{ __('Footer') }}</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"><i class="fas fa-home"></i>{{ __('Home') }}</a></li>
                    <li class="breadcrumb-item">{{ __('Footer') }}</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">{{ __('Footer Information') }} </h3>
                        <div class="card-tools">
                            <div class="d-inline-block">
                                <select class="form-control lang" id="languageSelect" data="{{url()->current() . '?language='}}">
                                    @foreach($langs as $lang)
                                        <option value="{{$lang->code}}" {{$lang->code == request()->input('language') ? 'selected' : ''}} >{{$lang->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="card-body">
                        <form class="form-horizontal" action="{{ route('admin.footer.update', $footerinfo->language_id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
   
                            <div class="form-group row">
                                <label class="col-sm-2 control-label">{{ __('Footer Text') }}<span
                                        class="text-danger">*</span></label>

                                <div class="col-sm-10">
                                    <textarea type="text" class="form-control textarea" name="footer_text" placeholder="{{ __('Footer Text') }}">{{ $footerinfo->footer_text }}</textarea>
                                    @if ($errors->has('footer_text'))
                                    <p class="text-danger"> {{ $errors->first('footer_text') }} </p>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 control-label">{{ __('Copyright Text') }}<span
                                        class="text-danger">*</span></label>

                                <div class="col-sm-10">
                                    <textarea type="text" class="form-control summernote" name="copyright_text" placeholder="{{ __('Copyright Text') }}">{{ $footerinfo->copyright_text }}</textarea>
                                    @if ($errors->has('copyright_text'))
                                    <p class="text-danger"> {{ $errors->first('copyright_text') }} </p>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="offset-sm-2 col-sm-10">
                                    <button type="submit" class="btn btn-primary">{{ __('Update') }}</button>
                                </div>
                            </div>

                        </form>

                    </div>
                    <!-- /.box-body -->
                </div>

            </div>
            <!-- /.col -->
        </div>
    </div>


</section>

@endsection

